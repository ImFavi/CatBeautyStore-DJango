from .models import Producto

class Carrito:
    def __init__(self, request):
        self.request = request
        self.session = request.session
        carrito = self.session.get("carrito")
        if not carrito:
            carrito = self.session["carrito"] = {}
        self.carrito = carrito 

    def agregar(self, producto):
        if producto.stock > 0:
            if producto.idProducto not in self.carrito.keys():
                self.carrito[producto.idProducto] = {
                    "producto_id": producto.idProducto,
                    "nombre": producto.nomProducto,
                    "marca": producto.marca.nomMarca,
                    "tipoProducto": producto.tipoProducto.nomTipoProducto,
                    "precio": str(producto.precio),
                    "cantidad": 1,
                    "total": producto.precio,
                }
                producto.stock -= 1
            else:
                for key, value in self.carrito.items():
                    if key == producto.idProducto:
                        if value["cantidad"] < producto.stock:
                            value["cantidad"] += 1
                            value["total"] += producto.precio
                            producto.stock -= 1
                        else:
                            # No se puede agregar más si el stock es insuficiente
                            return False
            producto.save()
        else:
            # No se puede agregar si no hay stock
            return False
        self.guardar_carrito()
        return True

    def guardar_carrito(self):
        self.session["carrito"] = self.carrito
        self.session.modified = True

    def eliminar(self, producto):
        id = producto.idProducto
        if id in self.carrito:
            cantidad_a_devolver = self.carrito[id]["cantidad"]
            del self.carrito[id]
            producto.stock += cantidad_a_devolver
            producto.save()
            self.guardar_carrito()
    
    def restar(self, producto):
        for key, value in self.carrito.items():
            if key == producto.idProducto:
                value["cantidad"] -= 1
                value["total"] -= producto.precio
                producto.stock += 1
                if value["cantidad"] < 1:
                    self.eliminar(producto)
                else:
                    producto.save()
                break
        self.guardar_carrito()
     
    def limpiar(self):
        for item in self.carrito.values():
            producto = Producto.objects.get(idProducto=item["producto_id"])
            producto.stock += item["cantidad"]
            producto.save()
        self.session["carrito"] = {}
        self.session.modified = True

