from django.urls import path
from . import views
from core.views import plantillaBase

urlpatterns = [
    path('plantillaBase/', plantillaBase),
    path('', views.index, name = "index"),
    path('productos/', views.productos, name = "productos"),
    path('contacto/', views.contacto, name = "contacto"),
    path('crearProductos/', views.crearProductos, name = "crearProductos"),
    path('editarProducto/<id>/', views.editarProducto, name='editarProducto'),
    path('eliminarProducto/<id>/', views.eliminarProducto, name='eliminarProducto'),
    path('crearComentario/', views.crearComentario, name="crearComentario"),
    path('eliminarComentario/<id>/', views.eliminarComentario, name='eliminarComentario'),
    path('productosVisitante/', views.productosVisitante, name = "productosVisitante"),
    path('productosCliente/', views.productosCliente, name = "productosCliente"),
    path('nosotros/', views.nosotros, name = 'nosotros'),
    path('logout/', views.cerrarSesion, name = 'cerrar_sesion'),
    path('registrar/', views.registrar, name="registrar"),
    path('quiz/',views.quiz, name="quiz"),

    path('agregar/<id>', views.agregar_producto, name="agregar"),
    path('eliminar/<id>', views.eliminar_producto, name="eliminar"),
    path('restar/<id>', views.restar_producto, name="restar"),
    path('limpiar/', views.limpiar_carrito, name="limpiar"),
    path('generarBoleta/', views.generarBoleta,name="generarBoleta"),
]