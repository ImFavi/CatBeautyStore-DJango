from django import forms 
from django.forms import ModelForm
from django.forms import widgets
from django.forms.widgets import Widget
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Marca, TipoProducto, Producto, Comentario

class RegistroUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']

class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ['idProducto', 'nomProducto', 'precio', 'imagenProducto', 'marca', 'tipoProducto', 'stock']
        labels = {
            'idProducto': 'ID de Producto',
            'nomProducto': 'Nombre de Producto',
            'precio': 'Precio',
            'imagenProducto': 'Imagen de Producto',
            'marca': 'Marca',
            'tipoProducto': 'Tipo de Producto',
            'stock': 'Stock'
        }
        widgets = {
            'idProducto': forms.TextInput(
                attrs={
                    'class': 'form-control',
                    'placeholder': 'Ingrese ID de Producto',
                    'id': 'idProducto'
                }
            ),
            'nomProducto': forms.TextInput(
                attrs={
                    'class': 'form-control',
                    'placeholder': 'Nombre del Producto',
                    'id': 'nomProducto'
                }
            ),
            'precio': forms.NumberInput(
                attrs = {
                    'class': 'form-control',
                    'placeholder': 'Precio',
                    'id': 'precio'
                }
            ),
            'imagenProducto': forms.FileInput(
                attrs={
                    'class': 'form-control',
                    'id': 'imagenProducto'
                }
            ),
            'marca': forms.Select(
                attrs={
                    'class': 'form-control',
                    'id': 'marca'
                }
            ),
            'tipoProducto': forms.Select(
                attrs={
                    'class': 'form-control',
                    'id': 'tipoProducto'
                }
            ),
            'stock': forms.NumberInput(
                attrs={
                    'class': 'form-control',
                    'id': 'stock'
                }
            )
        }

class ComentarioForm(forms.ModelForm):
    class Meta:
        model = Comentario
        fields = ['idComentario', 'nomUsuario', 'nomProducto', 'comentario']
        labels = {
            'idComentario': 'ID de Comentario',
            'nomUsuario': 'Nombre de Usuario',
            'nomProducto': 'ID de Producto',
            'comentario': 'Comentario'            
        }
        widgets = {
            'idComentario': forms.TextInput(
                attrs= {
                    'class': 'form-control',
                    'placeholder': 'ID de Comentario',
                    'id': 'idComentario'
                }
            ),
            'nomUsuario': forms.TextInput(
                attrs= {
                    'class': 'form-control',
                    'placeholder': 'Nombre de Usuario',
                    'id': 'nomUsuario'
                }
            ),
            'nomProducto': forms.Select(
                attrs={
                    'class': 'form-control',
                    'id': 'nomProducto'
                }
            ),
            'comentario': forms.Textarea(
                attrs={
                    'class': 'form-control',
                    'placeholder': 'Ingrese su Comentario',
                    'id': 'comentario'
                }
            ),
        }