from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import logout, authenticate, login
from django.contrib.auth.decorators import login_required
from .models import Marca, TipoProducto, Producto, Comentario, Boleta, detalle_boleta
from .forms import ProductoForm, ComentarioForm, RegistroUserForm
from django.contrib.auth.forms import UserCreationForm
from core.compras import Carrito
from django.contrib import messages
from django.http import JsonResponse

# PLANTILLA BASE
def plantillaBase(request):
    return render(request, "plantillaBase.html", {})


# Create your views here.
def index(request):
    return render(request, 'index.html')

def quiz(request):
    return render(request,'quiz.html')

def nosotros(request):
    return render(request, 'nosotros.html')

# PRODCUTOS VISITANTE
def productosVisitante(request):
    productos = Producto.objects.all()

    return render(request, 'productosVisitante.html', {"productos": productos})

# PRODUCTOS
@login_required
def productos(request):
    productos = Producto.objects.all()
    comentarios = Comentario.objects.all()

    return render(request, 'productos.html', {"productos": productos, "comentarios": comentarios})

def contacto(request):
    return render(request, 'contacto.html')

def productosCliente(request):
    productos = Producto.objects.all()
    comentarios = Comentario.objects.all()

    return render(request, 'productosCliente.html', {"productos": productos, "comentarios": comentarios})

# CREAR PRODUCTOS
def crearProductos(request):
    if request.method == 'POST':
        productoForm = ProductoForm(request.POST, request.FILES)
        if productoForm.is_valid():
            productoForm.save()
            return redirect('productos')
    else:
        productoForm = ProductoForm()
    return render(request, 'crearProductos.html', {'productoForm': productoForm})
        
# EDITAR PRODUCTOS
def editarProducto(request, id):
    producto = Producto.objects.get(idProducto=id)
    datos = {
        'formodificar': ProductoForm(instance=producto),
        'producto': producto
    }
    if request.method == 'POST':
        formulario = ProductoForm(request.POST, request.FILES, instance=producto)
        if formulario.is_valid():
            formulario.save()
            return redirect('productos')
    return render(request, 'editarProducto.html', datos)

# ELIMINAR PRODUCTOS
def eliminarProducto(request, id):
    producto = get_object_or_404(Producto, idProducto = id)
    if request.method == 'POST':
        if 'elimina' in request.POST:
            producto.delete()
            return redirect(productos)
    return render(request, 'eliminarProducto.html', {'producto': producto})

# COMENTARIOS
def crearComentario(request):
    formulario = ComentarioForm() 
    if request.method == 'POST':
        formulario = ComentarioForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('productos')
    
    return render(request, 'crearComentario.html', {'ComentarioForm': formulario})

# ELIMINAR COMENTARIO
def eliminarComentario(request, id):
    comentario = Comentario.objects.get(idComentario=id)
    if request.method == 'POST':
        if 'elimina' in request.POST:
            comentario.delete()
            return redirect(productos)
    return render(request, 'eliminarComentario.html', {'comentario': comentario})

# LOG OUT
def cerrarSesion(request):
    logout(request)
    return redirect('index')

def registrar(request):
    data={
        'form': RegistroUserForm()
    }
    if request.method=='POST':
        formulario = RegistroUserForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            user = authenticate(username=formulario.cleaned_data["username"],
                                password=formulario.cleaned_data["password1"])
            login(request, user)
            return redirect('index')
        data["form"]=formulario
    return render(request, 'registration/registrar.html',data)


def agregar_producto(request, id):
    carrito_compra = Carrito(request)
    producto = get_object_or_404(Producto, idProducto=id)
    if not carrito_compra.agregar(producto=producto):
        messages.error(request, 'No hay suficiente stock de este producto :c .')
    return redirect('productos')

def eliminar_producto(request, id):
    carrito_compra= Carrito(request)
    producto = get_object_or_404(Producto, idProducto=id)
    carrito_compra.eliminar(producto=producto)
    return redirect('producto')

def restar_producto(request, id):
    carrito_compra = Carrito(request)
    producto = get_object_or_404(Producto, idProducto=id)
    carrito_compra.restar(producto=producto)
    return redirect('productos')

def limpiar_carrito(request):
    carrito_compra= Carrito(request)
    carrito_compra.limpiar()
    return redirect('productos')    



def generarBoleta(request):
    if not request.session.get('carrito') or not request.session['carrito']:
        messages.error(request, 'No hay productos en el carrito, agrega tus productos.')
        return redirect('productos')
    
    precio_total = 0
    for key, value in request.session['carrito'].items():
        precio_total = precio_total + int(value['precio']) * int(value['cantidad'])
    
    boleta = Boleta(total=precio_total)
    boleta.save()
    
    productos = []
    for key, value in request.session['carrito'].items():
        producto = Producto.objects.get(idProducto=value['producto_id'])
        cant = value['cantidad']
        subtotal = cant * int(value['precio'])
        detalle = detalle_boleta(id_boleta=boleta, id_producto=producto, cantidad=cant, subtotal=subtotal)
        detalle.save()
        productos.append(detalle)
    
    datos = {
        'productos': productos,
        'fecha': boleta.fechaCompra,
        'total': boleta.total
    }
    
    request.session['boleta'] = boleta.id_boleta
    
    carrito = Carrito(request)
    carrito.limpiar()
    
    return render(request, 'detallecarrito.html', datos)
