$(function(){
    $("#formulario").validate({
        rules:{
            idProducto: {
                required: true,
                minlength: 3,
                maxlength: 10
            },
            nomProducto: {
                required: true,
                maxlength: 40,
            },
            precio: {
                required: true,
                number: true
            },
            marca: {
                required: true
            },
            tipoProducto: {
                required: true
            },
            stock: {
                required: true,
                number: true
            },
        },
        messages:{
            idProducto:{
                required: "Ingrese ID de Producto",
                minlength: "Minimo 3 Caracteres/Digitos",
                maxlength: "Maximo 10 Caracteres"
            },
            nomProducto:{
                required: "Ingrese Nombre de Producto",
                maxlength: "Maximo 40 Caracteres"
            },
            precio:{
                required: "Ingrese Precio de Producto",
                number: "Solamente Ingresar Numeros"
            },
            marca:{
                required: "Seleccione Marca de Producto"
            },
            tipoProducto:{
                required: "Seleccione Tipo de Producto"
            },
            stock:{
                required: "Ingrese Stock de Producto",
                number: "Solamente Ingresar Numeros"
            }
        }
    });
});